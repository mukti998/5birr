// POST /provider-approval
// Body: { provider_id, action: 'APPROVE'|'REJECT', reason? }
import { corsHeaders, requireRole, getAdminClient, json } from "../_shared/client.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const { user } = await requireRole(req, "ADMIN");
    const { provider_id, action, reason } = await req.json();
    if (!provider_id || !action) return json({ error: "provider_id and action required" }, 400);

    const admin = getAdminClient();
    let data, error;

    if (action === "APPROVE") {
      ({ data, error } = await admin.rpc("approve_provider", {
        p_provider_id: provider_id,
        p_admin_id: user.id,
      }));
    } else if (action === "REJECT" || action === "REQUEST_CORRECTION") {
      if (!reason) return json({ error: "reason is required for rejection/correction" }, 400);
      ({ data, error } = await admin.rpc("reject_provider", {
        p_provider_id: provider_id,
        p_admin_id: user.id,
        p_reason: reason,
      }));
    } else {
      return json({ error: "Unsupported action" }, 400);
    }

    if (error) return json({ error: error.message }, 400);
    return json({ provider: data });
  } catch (e) {
    if (e instanceof Response) return e;
    return json({ error: String(e) }, 500);
  }
});
